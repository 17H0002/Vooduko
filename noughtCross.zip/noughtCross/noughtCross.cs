﻿using System;
using System.IO;

namespace noughtCross
{
    class Game
    {
        static StreamWriter w;
        static StreamReader r;
        static Board board;
        static Player player1;
        static Player player2;
        static Player currentPlayer;
        static bool game;
        static int turnCount = 0;

        static void Main(string[] args)
        {
            game = true;
            Console.WriteLine("\n--------------------Welcome to Noughts and Crosses!!--------------------\n");
            Console.Write("Continue from the previous game or start a new game? N or C: ");
            char choice = Convert.ToChar(Console.ReadLine());

            switch(choice)
            {
                case 'N': 
                    initGame();
                    Console.WriteLine($"------------------------------------------------------------------------\nPlayers:\n\n{player1.ToString()}\n\n{player2.ToString()}");
                    Console.WriteLine("------------------------------------------------------------------------");
                    Console.Write(board.ToString()); 
                    break;
                case 'n': 
                    initGame();
                    Console.WriteLine($"------------------------------------------------------------------------\nPlayers:\n\n{player1.ToString()}\n\n{player2.ToString()}");
                    Console.WriteLine("------------------------------------------------------------------------");
                    Console.Write(board.ToString());
                    break;
                case 'C': 
                    loadGame();
                    Console.WriteLine($"------------------------------------------------------------------------\nPlayers:\n\n{player1.ToString()}\n\n{player2.ToString()}");
                    Console.WriteLine("------------------------------------------------------------------------");
                    Console.Write(board.ToString()); 
                    break;
                case 'c': 
                    loadGame(); 
                    Console.WriteLine($"------------------------------------------------------------------------\nPlayers:\n\n{player1.ToString()}\n\n{player2.ToString()}");
                    Console.WriteLine("------------------------------------------------------------------------");
                    Console.Write(board.ToString());
                    break;
                default: initGame(); break;
            }

            currentPlayer = player1;
            
            while(game)
            {
                while(game && turnCount <  board.BoardSize * board.BoardSize)
                {
                    turnCount++;
                    turn();
                }

                if(turnCount >= board.BoardSize * board.BoardSize && !Win(currentPlayer.Token))
                {
                    Console.WriteLine("It is a draw");
                }

                Console.Write("Would you like to play another round? Y/N: ");
                char temp = Convert.ToChar(Console.ReadLine());
                if(temp == 'Y' || temp == 'y')
                {
                    board.setBoard();
                    turnCount = 0;
                    game = true;
                    Console.WriteLine($"------------------------------------------------------------------------\nPlayers:\n\n{player1.ToString()}\n\n{player2.ToString()}");
                    Console.WriteLine("------------------------------------------------------------------------");
                    Console.Write(board.ToString());
                }
                else
                {
                    game = false;
                }    
            }

            Console.Write("Would you like to save your game? Y/N: ");
            char temp2 = Convert.ToChar(Console.ReadLine());
            if(temp2 == 'Y' || temp2 == 'y')
            {
                storeGame(board, player1, player2);
            }
            else
            {
                w = new StreamWriter("File.txt");
                w.Close();
            }
        }

        static void initGame()
        {
            Console.Write("Enter the board size followed by the style:\n");
            board = new Board(Convert.ToInt32(Console.ReadLine()), Convert.ToChar(Console.ReadLine()));
            Console.Write("Enter the name and token for player 1:\n");
            player1 = new Player(Console.ReadLine(), Convert.ToChar(Console.ReadLine()));
            Console.Write("Enter the name and token for player 2:\n");
            player2 = new Player(Console.ReadLine(), Convert.ToChar(Console.ReadLine()));
            
        }

        static void loadGame()
        {
            r = new StreamReader("File.txt");
            bool read = true;
            int linesRead = 0;

            while(read)
            {
                string temp = r.ReadLine();
                linesRead++;
                if(temp == null && linesRead <= 1)
                {
                    read = false;
                    Console.WriteLine("There are no previous games, please start a new game.\n");
                    initGame();
                    break;
                }
                else if(temp != null)
                {
                    string[] arr = temp.Split(' ');
                    
                    switch(arr[0])
                    {
                        case "b":
                        board = new Board(Convert.ToInt32(arr[1]), Convert.ToChar(arr[2]));
                        break;
                        case "p1":
                        player1 = new Player(arr[1], Convert.ToChar(arr[2]), Convert.ToDouble(arr[3]));
                        break;
                        case "p2":
                        player2 = new Player(arr[1], Convert.ToChar(arr[2]), Convert.ToDouble(arr[3]));
                        break;
                        default:
                        break;

                    }
                }
                else
                {
                    read = false;
                }
            }
            r.Close();
        }

        static void storeGame(Board b, Player p1, Player p2)
        {
            w = new StreamWriter("File.txt");
            if(board != null && p1 != null && p2 != null)
            {
                w.WriteLine($"b {b.BoardSize} {b.BoardStyle}");
                w.WriteLine($"p1 {p1.Name} {p1.Token} {p1.Score}");
                w.WriteLine($"p2 {p2.Name} {p2.Token} {p2.Score}");
            }
            w.Close();
        }

        static bool Win(char token)
        {
            //ROWS
            bool winRows = false;
            int falseCount = 0;
            for(int row = 0; row < board.BoardSize; row++)
            {
                for(int col = 0; col < board.BoardSize; col++)
                {
                    if(board.PlayerBoard[row, col] != token)
                    {
                        falseCount++;
                        break;
                    }
                }
            }
            if(falseCount == board.BoardSize - 1){winRows = true;} 

            //COLS
            bool winCols = false;
            int falseCount2 = 0;
            for(int col = 0; col < board.BoardSize; col++)
            {
                for(int row = 0; row < board.BoardSize; row++)
                {
                    if(board.PlayerBoard[row, col] != token)
                    {
                        falseCount2++;
                        break;
                    }
                }
            }
            if(falseCount2 == board.BoardSize - 1){winCols = true;} 

            //DIAGONALS
            bool winDiag = true;
            for(int i = 0; i < board.BoardSize; i++)
            {
                if(board.PlayerBoard[i, i] != token){
                    winDiag = false;
                    break;
                }
            }

            bool winDiag2 = true;
            for(int i = 0; i < board.BoardSize; i++)
            {
                if(board.PlayerBoard[i, board.BoardSize -1 - i] != token){
                    winDiag2 = false;
                    break;
                }
            }

            if(winRows || winCols || winDiag || winDiag2)
            {
                game = false;
                return true;
            }
            else
            {
                return false;
            }
        }

        static void turn()
        {
            string play = "";
            bool turn = true;
            while(turn)
            {
                Console.Write($"{currentPlayer.Name}'s turn, choose a position in the format (1 1), (2 2) etc: ");
                play = Console.ReadLine();
                int playRow = Convert.ToInt32(play.Substring(0,1));
                int playCol = Convert.ToInt32(play.Substring(2,1));

                if(board.PlayerBoard[playRow - 1, playCol - 1] == 'X' || board.PlayerBoard[playRow - 1, playCol - 1] == 'O')
                {
                    Console.WriteLine("\n***Invalid play, choose an unoccupied space on the board***\n");
                }
                else
                {
                    board.PlayerBoard[playRow - 1, playCol - 1] = currentPlayer.Token;
                    Console.Write(board.ToString());
                    turn = false;
                    if(currentPlayer == player1)
                    {
                        if(Win(currentPlayer.Token))
                        {
                            currentPlayer.Score++;
                            Console.WriteLine($"{currentPlayer.Name} has Won!");
                            break;
                        }else{
                            currentPlayer = player2;
                        }
                    }
                    else
                    {
                        if(Win(currentPlayer.Token))
                        {
                            currentPlayer.Score++;
                            Console.WriteLine($"{currentPlayer.Name} has Won!");
                            break;
                        }else{
                            currentPlayer = player1;
                        }
                    }
                }       
            }            
        }
    }

    class Board
    {
        public char[,] PlayerBoard {get; private set;}
        public int BoardSize {get; private set;}
        public char BoardStyle;

        public void setBoard(){
            
            for(int row = 0; row < BoardSize; row++)
            {
                for(int col = 0; col < BoardSize; col++)
                {
                    PlayerBoard[row, col] = BoardStyle;
                }
            }
        }

        public override string ToString(){
            
            string output = "\n";
            for(int row = 0; row < BoardSize; row++)
            {
                for(int col = 0; col < BoardSize; col++)
                {
                    output += $" {PlayerBoard[row, col]} ";
                }
                output += "\n\n";
            }

            return output;
        }

        public Board(int size, char boardStyle){
            BoardSize = size;
            BoardStyle = boardStyle;
            PlayerBoard = new char[size, size];
            setBoard();
        }
    }

    class Player
    {
        public string Name {get; private set;}

        public double Score = 0;

        public char Token {get; private set;}

        public override string ToString()
        {
            return $"{Name}, Token: {Token}, Score: {Score}";
        }

        public Player(string name, char token)
        {
            Name = name;
            Token = token;
        }

        public Player(string name, char token, double score)
        {
            Name = name;
            Token = token;
            Score = score;
        }
    }
}
