﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dooko
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    enum playerType { player1, player2, computerAI }
    class board
    {
        public board()
        {

        }
    }
    class game
    {
        public string gameName { get; set; }
        public string[] playerNames { get; set; }
        public playerType player { get; set; }
        public board Board { get; set; }
        public int gameMode { get; set; } //gameMode = 0 ~ Single player sudoku. gameMode = 1 ~ Two player sudoku. gameMode = 2 ~ Single player suduko against the computer.
        public bool gameOn { get; set; } //gameOn = false ~ game has ended. gameOn = true ~ game is in play.
        public int numMoves { get; set; }
        public string message { get; set; }
        public int rowText { get; set; }
        public int moveCol { get; set; }
        public int move { get; set; }
        //Initialiser for all sudoku games.
        public game()
        {

        }
        //Initialiser for loading previous games.
        public game(string name, string[] players, playerType p, board b, int mode, bool on, int moves, string m, int r, int mc, int mov)
        {
            gameName = name;
            playerNames = players;
            player = p;
            Board = b;
            gameMode = mode;
            gameOn = on;
            numMoves = moves;
            message = m;
            rowText = r;
            moveCol = mc;
            move = mov;
        }
    }
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        
        List<board> boards = new List<board>() { };
        List<game> games = new List<game>() { };
        game currentGame = new game();

        public void move()
        {
            //Contains relevant code concerning the procedure for the computer to make a move.
        }
        public bool check1()
        {
            //Contains relevant code concerning the first check procedure.
            return true;
        }
        public bool check2()
        {
            //Contains relevant code concerning the second check procedure.
            return true;
        }
        public bool check3()
        {
            //Contains relevant code concerning the third check procedure.
            return true;
        }
        public bool check4()
        {
            //Contains relevant code concerning the fourth check procedure.
            return true;
        }
        //Check procedures.
        public bool check()
        {
            if(check1() == false && check2() == false && check3() == false && check4() == false)
            {
                return false;
            } else
            {
                return true;
            }
        }
        //Determine the current player (Control)
        public void determinePlayer()
        {
            if(currentGame.gameMode == 0)
            {
                currentGame.player = playerType.player1;
            } else if(currentGame.gameMode == 1)
            {
                switch (currentGame.player)
                {
                    case playerType.player1: currentGame.player = playerType.player2; break;
                    case playerType.player2: currentGame.player = playerType.player1; break;
                    default: break;
                }
            }
            else
            {
                switch (currentGame.player)
                {
                    case playerType.player1: currentGame.player = playerType.computerAI; break;
                    case playerType.computerAI: currentGame.player = playerType.player1; break;
                    default: break;
                }
            }
        }
        //Displays results of an invalid move (View)
        public void result()
        {
            if (currentGame.gameOn == false)
            {
                switch (currentGame.player)
                {
                    case playerType.player1: if (currentGame.gameMode == 0) { currentGame.message = "You died."; }
                                             if (currentGame.gameMode == 1) { currentGame.message = currentGame.playerNames[1] + " wins! Flawless victory!"; }
                                             if (currentGame.gameMode == 2) { currentGame.message = "You died."; }
                                             break;
                    case playerType.player2: currentGame.message = currentGame.playerNames[0] + " wins! Flawless victory!"; break;
                    case playerType.computerAI: currentGame.message = currentGame.playerNames[0] + " wins! Flawless victory!"; break;
                    default: break;
                }
            }
        }
        //To be implemented in trigger (Model)
        public void button()
        {
            determinePlayer();
            if(currentGame.player == playerType.computerAI)
            {
                move();
            }
            else
            {
                check();
            }
            result();
        }
    }
}
